package interfaces.FoH;

public interface IStaff {
    void getStaffHours(int UNIXtimestamp_Date); // returns a 2D array of all the staff working per half hour shift on a given date
}
