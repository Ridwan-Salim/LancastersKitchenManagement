package interfaces.FoH;

public interface IMenu {
    void getMenuPDF(int UNIXtimestamp_Date); // returns a printable PDF of the menu, updated weekly
}
